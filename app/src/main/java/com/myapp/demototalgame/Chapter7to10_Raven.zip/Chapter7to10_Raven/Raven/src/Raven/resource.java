/**
 * @author Petr (http://www.sallyx.org/)
 */
package Raven;

public class resource {

    final public static int IDR_MENU1 = 101;
    final public static int ID_MENU_LOAD = 40001;
    final public static int IDM_MAP_LOAD = 40001;
    final public static int IDM_GAME_LOAD = 40001;
    final public static int IDM_NAVIGATION_SHOW_NAVGRAPH = 40002;
    final public static int IDM_NAVIGATION_SHOW_PATH = 40004;
    final public static int IDM_NAVIGATION_SMOOTH_PATHS_QUICK = 40005;
    final public static int IDM_BOTS_SHOW_IDS = 40006;
    final public static int IDM_BOTS_SHOW_HEALTH = 40007;
    final public static int IDM_BOTS_SHOW_TARGET = 40008;
    final public static int IDM_BOTS_SHOW_FOV = 40009;
    final public static int IDM_BOTS_SHOW_SCORES = 40010;
    final public static int IDM_BOTS_SHOW_GOAL_Q = 40011;
    final public static int IDM_NAVIGATION_SHOW_INDICES = 40012;
    final public static int IDM_MAP_ADDBOT = 40013;
    final public static int IDM_GAME_ADDBOT = 40013;
    final public static int IDM_MAP_REMOVEBOT = 40014;
    final public static int IDM_GAME_REMOVEBOT = 40014;
    final public static int IDM_NAVIGATION_SMOOTH_PATHS_PRECISE = 40015;
    final public static int IDM_BOTS_SHOW_SENSED = 40016;
    final public static int IDM_GAME_PAUSE = 40017;

    /*
     // Next default values for new objects
     // 
     #ifdef APSTUDIO_INVOKED
     #ifndef APSTUDIO_READONLY_SYMBOLS
     #define _APS_NEXT_RESOURCE_VALUE        111
     #define _APS_NEXT_COMMAND_VALUE         40018
     #define _APS_NEXT_CONTROL_VALUE         1000
     #define _APS_NEXT_SYMED_VALUE           101
     #endif
     #endif
     */
}
