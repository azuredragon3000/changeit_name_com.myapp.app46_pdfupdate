/**
 *
 * @author Petr (http://www.sallyx.org/)
 */
package Raven;

final public class Constants {
    final public static int WindowWidth = 500;
    final public static int WindowHeight = 500;
    final public static int FrameRate = 60;
}
