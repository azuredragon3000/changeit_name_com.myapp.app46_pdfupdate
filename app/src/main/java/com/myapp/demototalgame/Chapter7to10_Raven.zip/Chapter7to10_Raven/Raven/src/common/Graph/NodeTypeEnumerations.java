/**
 * @author Petr (http://www.sallyx.org/)
 * Desc:   enumerates some dummy node values that can be assigned to graph
 *         edges and nodes
 */
package common.Graph;

//-----------------------------------------------------------------------------
public class NodeTypeEnumerations {
    final public static int invalid_node_index = -1;
}
