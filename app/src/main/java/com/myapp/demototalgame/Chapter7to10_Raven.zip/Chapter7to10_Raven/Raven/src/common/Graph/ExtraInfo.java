/*
 * 
 *  @author Petr (http://www.sallyx.org/)
 */
package common.Graph;

/**
 *
 * @author Petr
 */
public interface ExtraInfo {
    public  boolean isActive();
    public int EntityType();
}
